document.addEventListener('click', function(event) {
  // クリックされた要素とその親要素をチェック
  const targetElement = event.target.closest('div.TimelineItem-body > details.review-thread-component > summary.color-bg-subtle > div > span > a.Link--primary');
  
  if (targetElement) {
    // クリックイベントのデフォルト動作を防ぐ
    event.preventDefault();
    
    // 内部テキストを取得
    const textContent = targetElement.textContent.trim();
    
    if (textContent) {
      // クリップボードにコピー
      navigator.clipboard.writeText(textContent).then(() => {
        // コピー成功時の視覚的フィードバック
        const originalColor = targetElement.style.color;
        targetElement.style.color = '#2da44e';
        
        setTimeout(() => {
          targetElement.style.color = originalColor;
        }, 500);
      }).catch(err => {
        console.error('クリップボードへのコピーに失敗しました:', err);
      });
    }
  }
}); 
