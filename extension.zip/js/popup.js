document.addEventListener('DOMContentLoaded', function() {
  // ここに拡張機能のロジックを追加してください
  console.log('拡張機能が読み込まれました');
}); 
